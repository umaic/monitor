<?php
/**
 * Main controller
 *
 * @package     Monitor
 * @link 		http://monitor.colombiashh.org/api
 */

class MonitorController {
    
    private $db_dn;
    private $db;

    function __construct() {
        
        require 'libraries/factory.php';
        
        $this->db = Factory::create('mysql');
        $this->db_dn = 'inundacionesv2_1';    
    }

    /**
     * Display Home
     *
     */ 
    public function index() {

        require 'libraries/factory.php';
        
        $f = Factory::create('file');

        if ($ecj = @file_get_contents('http://colombiassh.org/emergenciacompleja/ec.json')) {
            
            $fp = $f->open('data/ec.json', 'w+');
            $f->write($fp, $ecj);
            $f->close($fp);

            return true;
        }

       return false; 

    }
    
    /**
     * Get total of incidents per year to top menu
     *
     */ 
    public function total() {
        
        /*
        require 'libraries/factory.php';
        
        $f = Factory::create('file');
        $p = 'data/monitor.json';

        $fp = $f->open($p, 'r');
        $j = $f->read($fp, $p);
        $i = json_decode($j, true);

        //echo json_encode(array('h' => array(2012,2011,2013)));

        return $i['totales'];
         */
        
        $_sql = 'SELECT COUNT(id) AS n FROM %sincident WHERE YEAR(incident_date) = %d AND incident_active = 1';
        $yi = 2008;
        $yf = date('Y');
        $t = array();
        for($_y=$yf;$_y>=$yi;$_y--){
            
            $_rse = $this->db->open(sprintf($_sql, '', $_y));
            $_ec = $this->db->FO($_rse);
            
            $_rsd = $this->db->open(sprintf($_sql, $this->db_dn.'.', $_y));
            $_dn = $this->db->FO($_rsd);

            $t[$_y] = array('ec' => $_ec->n, 'dn' => $_dn->n);
        }

        return $t;

    }
    
    /**
     * Get total of incidents per depto
     *
     */ 
    public function totalxd() {
        
        $r = array();
        $_sql = "SELECT COUNT(l.id) AS n FROM %slocation AS l
                 JOIN incident AS i ON l.id = i.location_id
                 WHERE state_id = '%s' AND incident_active = 1 LIMIT 1";

        $_rs = $this->db->open('SELECT id,state,centroid FROM state ORDER BY state');
        while($_row = $this->db->FO($_rs)) {
            
            $_rse = $this->db->open(sprintf($_sql,'',$_row->id));
            $_ec = $this->db->FO($_rse);
            $_nec = (empty($_ec->n)) ? '---' : $_ec->n;

            $_rsd = $this->db->open(sprintf($_sql,$this->db_dn.'.',$_row->id));
            $_dn = $this->db->FO($_rsd);
            $_ndn = (empty($_dn->n)) ? '---' : $_dn->n;

            $r[] = array('d' => $_row->state,
                         'ec' => $_nec,
                         'dn' => $_ndn,
                         'c' => $_row->centroid
                        );
        }
        return $r;
    }
    
    /**
     * Total Ec y Dn
     *
     */ 
    public function totalecdn() {
        
        $_sql = "SELECT COUNT(id) AS n FROM incident";
        $_rs = $this->db->Open($_sql);
        $_row = $this->db->FO($_rs);
        $r['ec'] = $_row->n;
        
        $_sql = "SELECT COUNT(id) AS n FROM $this->db_dn.incident";
        $_rs = $this->db->Open($_sql);
        $_row = $this->db->FO($_rs);
        $r['dn'] = $_row->n;

        return $r;
    }
}
