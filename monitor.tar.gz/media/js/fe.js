$(function(){

    var _mes = ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'];

    $("#loading")
    .ajaxStart(function(){ $('#loading').show(); })
    .ajaxStop(function(){ $('#loading').hide(); });
    
    // Intro text
    $('#lmh').click(function() {
        m({
            t: 'Monitor - ColombisSSH',
            hid: 'qlmh',
            w: 600,
            h: 400
        });
		
        // prevent the default action
		return false;
	});
    
    // Date events
    var _ms = 2;  // Meses hacia atras

    var _today = new Date();
    var _ini = new Date().setDate(_today.getDate()-60);

	$("#dslider").dateRangeSlider({
        bounds: 
                {
                min: new Date(2012,0,1).getTime(), 
                max: new Date().getTime()
                },
        defaultValues:
                {
                min: _ini, 
                max: new Date().getTime()
                },
        formatter: function(value) {
            return _mes[value.getMonth()] + ' ' + value.getDate();
            },
        step: { days: 1},
        
        userValuesChanged: function(v){ console.log(v); }
    });

    // Years menu
    $('#aaaa div.v').click(function() { 
        var _y = parseInt($(this).find('div.a').text());
        $('#startDate').val(new Date(_y,0,1).getTime()/1000);
        $('#endDate').val(new Date(_y,11,31).getTime()/1000);

        addFeaturesFirstTime();

        $('#totalxd_y').html(_y);
        
        var bmin = new Date(_y,0,1);
        var bmax = (_y == new Date().getFullYear()) ? new Date() : new Date(_y,11,31);
        
        $('#dslider').dateRangeSlider('bounds', bmin, bmax);
        $('#dslider').dateRangeSlider('values', bmin, bmax);

    });

    map();
});

m = function(o){	
	
    if($('#dialog').size()){
		$('#dialog').dialog('destroy');
	}
    else { 
		$('body').append('<div id="dialog"></div>')
    }

	//$('#dialog').html('<img src="img/loading.gif">&nbsp;Loading....');

	if(o.hid){
		 $('#dialog').html($('#' + o.hid).html());
	}
    else if (o.html) {
        $('#dialog').html(o.html);
    }
    else if(o.u){
		$('#dialog').load(o.u, function(r, s, x){
			 if (s == "error" &&  x.status == 403) window.location.href  = '/';		 
		});
	}
     
     sm(o);
}

// it shows a modal dialog
sm = function(o){
	$('#dialog').dialog({
		height: (o.h ? o.h : 500),
		width:  (o.w ? o.w : 900),
		modal: true,
		title: o.t,
		close: function(){ $(this).dialog('destroy'); $(this).remove()}
	});
}
