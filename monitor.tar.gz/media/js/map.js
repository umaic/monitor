var base = 'sissh';
var map;
var pL;
var fromProjection;
var toProjection;
var features_ec;
var features_dn;
var markerRadius = 5;
var Style;
var mtipo;
var clear = true;
var request = false;
var filtro = id_filtro = '';
var nump_list = 15;
var id_depto = '00';
var rm_id_depto = false;
var id_tema = id_org = 0;
var url_xd = '/json/cluster/?m=0&callback=?';
var url_ec = 'http://colombiassh.org/emergenciacompleja' + url_xd;
var url_dn = 'http://inundaciones.colombiassh.org' + url_xd;
var markerOpacity = 0.8;
var selectCtrl;
var l_ec, l_dn;
var mapLoad = 0;

function map() {
   
    fromProjection = new OpenLayers.Projection('EPSG:4326'); // World Geodetic System 1984 projection (lon/lat) 
    toProjection = new OpenLayers.Projection('EPSG:900913'); // WGS84 OSM/Google Mercator projection (meters) 
    OpenLayers.ImgPath = "media/js/openlayers/img/";
    
    // Deptos events
    $('#totalxd').find('tr').click(function(){
		var _c = $(this).find('td.centroid').html().split(',');
		map.setCenter(new OpenLayers.LonLat(_c[0], _c[1]), map.getZoom() + 2);
	});
    
    map = new OpenLayers.Map({
        div: "map",
        displayProjection: toProjection, 
        theme: 'media/js/openlayers/theme/default/style.min.css',
        eventListeners: {
            "zoomend": mapMove
        }
    });
    
    map.maxExtent = new OpenLayers.Bounds(
			-9099122, -471155, -7441396, 1505171  // Colombia con San Andrés
    );
    
    //map.restrictedExtent = map.maxExtent;

    var ly = new OpenLayers.Layer.OSM("Openstreetmap","",
           {
                    resolutions: [156543.03390625, 78271.516953125,
                                     39135.7584765625, 19567.87923828125, 9783.939619140625,
                                     4891.9698095703125,2445.9849047851562, 1222.9924523925781,
                                  611.4962261962891, 305.74811309814453, 152.87405654907226,
                                  76.43702827453613, 38.218514137268066, 19.109257068634033,
                                  9.554628534317017, 4.777314267158508, 2.388657133579254,

                                 ],
                    serverResolutions: [156543.03390625, 78271.516953125,
                                     39135.7584765625, 19567.87923828125, 9783.939619140625,
                                     4891.9698095703125, 2445.9849047851562, 1222.9924523925781,
                                     611.4962261962891, 305.74811309814453, 152.87405654907226,
                                     76.43702827453613, 38.218514137268066, 19.109257068634033,
                                     9.554628534317017, 4.777314267158508, 2.388657133579254,
                                     1.194328566789627, 0.5971642833948135, 0.29858214169740677,
                                     0.14929107084870338, 0.07464553542435169
                                    ]
			   
            });

    map.addLayer(ly);
    
    map.zoomTo(6);

    defStyle();
        
    addFeaturesFirstTime();

    var loadingpanel = new OpenLayers.Control.LoadingPanel();
    map.addControl(loadingpanel);

    
}

function addFeaturesFirstTime() {
    addFeatures($("#currentCat").val(),$("#startDate").val(),$("#endDate").val(),map.getZoom(),map.getCenter());
    mapLoad = 1;
}

function addFeatures(cat, start, end, zoom, center) {
   
    var uparams = [['c', cat],['s', start], ['e', end], ['z', zoom]];

    if (map.getLayersByName('Emergencia Compleja').length > 0) {
		l_ec = map.getLayersByName('Emergencia Compleja')[0];
        l_ec.removeFeatures(l_ec.features);
    }
    else {
		l_ec = new OpenLayers.Layer.Vector('Emergencia Compleja', 
            { styleMap: Styles });
	}
    
    if (map.getLayersByName('Desastres Naturales').length > 0) {
		var l_dn = map.getLayersByName('Desastres Naturales')[0];
        l_dn.removeFeatures(l_dn.features);
    }
    else {
		l_dn = new OpenLayers.Layer.Vector('Desastres Naturales', 
            { styleMap: Styles });
		
	}

    var _uec = addURLParameter(url_ec, uparams);
    var _udn = addURLParameter(url_dn, uparams);

    ajaxFeatures(_uec, l_ec);
    ajaxFeatures(_udn, l_dn);
/*
    selectCtrl = new OpenLayers.Control.SelectFeature([l_ec, l_dn],
        { 
            clickout: true,
            highlightOnly: true,
            onSelect: function(feature) { onFeatureSelect(feature.attributes)  }
        }
    );

    map.addControl(selectCtrl);
    selectCtrl.activate();
   
    l_ec.events.on({
        "featureselected": onFeatureSelect,
        "featureunselected": onFeatureUnselect
    });
    
    l_dn.events.on({
        "featureselected": onFeatureSelect,
        "featureunselected": onFeatureUnselect
    });*/

}

/**
* Display popup when feature selected
*/
function onFeatureSelect(attrs) {
    var _html = '';
    $.ajax({
        url: 'http://190.66.6.168/ecompleja/monitor/reports_list_map/?c=0&sw=-73.367778,4.314167&ne=-72.0825,5.720556&s=1293858000&e=1325307600',
        dataType: 'json',
        success: function(json){
            for(var i=0, j=json.length; i < j; i+=1) {
                _js = json[i];
                _html += '<div class="report_list_map" onclick="$(this).find(\'div.hide\').slideToggle()"> ' +
                    '<div class="t">'+ _js.t +'</div> ' +
                    '<div>' +
                        '<div class="date detail">'+ _js.d +'</div> ' +
                        '<div class="loc detail">'+ _js.l +'</div> ';
                        for(var k=0, l=_js.c.length; k< l; k += 1) {
                            _html += '<div class="cat detail">'+ _js.c[k] +'</div> ';
                        }

                _html += '<div class="clear"></div></div> ';
                _html += '<div class="desc hide">'+ _js.desc +'</div> ';

                if (_js.f != '') {
                    _html += '<div class="f hide">' +
                    '<div class="ft">Fuente de noticia</div>'; 
                    for(var k=0, l=_js.f.length; k< l; k += 1) {
                        _html += '<div>'+ _js.f[k] +'</div> ';
                    }
                }

                _html += '</div>';
            }

            // Modal window, in fe.js
            m({
                t: 'Monitor - ColombiaSSH :: Listado de eventos',
                html: _html,
                w: 800,
                h: 500
            });
        },
    });
    
}

function ajaxFeatures(u, l) {
    
    var geojson = new OpenLayers.Format.GeoJSON({
        'internalProjection': toProjection,
        'externalProjection': fromProjection});
    $.ajax({
        url: u,
        dataType: 'json',
        success: function(json){
                var _f = geojson.read(json);
                map.addLayer(l);
                l.addFeatures(_f);
                $('#loading').hide();
    
                    selectCtrl = new OpenLayers.Control.SelectFeature(l,
                        { 
                            clickout: true,
                            highlightOnly: true,
                            onSelect: function(feature) { onFeatureSelect(feature.attributes)  }
                        }
                    );

                    map.addControl(selectCtrl);
                    selectCtrl.activate();
            },
        beforeSend: function(){ $('#loading').show() }
    });
}

function mapMove(event)
{
    // Prevent this event from running on the first load
    if (mapLoad > 0)
    {
        // Get Current Category
        currCat = $("#currentCat").val();

        // Get Current Start Date
        currStartDate = $("#startDate").val();

        // Get Current End Date
        currEndDate = $("#endDate").val();

        // Get Current Zoom
        currZoom = map.getZoom();

        // Get Current Center
        currCenter = map.getCenter();
        

        
        // Refresh Map
        addFeatures(currCat, currStartDate, currEndDate, currZoom, currCenter);
        
    }
}

function defStyle(){
                
	var	style = new OpenLayers.Style({
				'externalGraphic': "${icon}",
				'graphicTitle': "${cluster_count}",
				pointRadius: "${radius}",
				fillColor: "${color}",
				fillOpacity: "${opacity}",
				strokeColor: "${strokeColor}",
				strokeWidth: "${strokeWidth}",
				strokeOpacity: "0.3",
				label:"${clusterCount}",
				//labelAlign: "${labelalign}", // IE doesn't like this for some reason
				fontWeight: "${fontweight}",
				fontColor: "#ffffff",
				fontSize: "${fontsize}"
			},


        {
				context:
				{
					count: function(feature)
					{
						if (feature.attributes.count < 2)
						{
							return 2 * markerRadius;
						} 
						else if (feature.attributes.count == 2)
						{
							return (Math.min(feature.attributes.count, 7) + 1) *
							(markerRadius * 0.8);
						}
						else
						{
							return (Math.min(feature.attributes.count, 7) + 1) *
							(markerRadius * 0.6);
						}
					},
					fontsize: function(feature)
					{
						feature_icon = feature.attributes.icon;
						if (feature_icon!=="")
						{
							return "9px";
						}
						else
						{
							feature_count = feature.attributes.count;
							if (feature_count > 1000)
							{
								return "20px";
							}
							else if (feature_count > 500)
							{
								return "18px";
							}
							else if (feature_count > 100)
							{
								return "14px";
							}
							else if (feature_count > 10)
							{
								return "12px";
							}
							else if (feature_count >= 2)
							{
								return "10px";
							}
							else
							{
								return "";
							}
						}
					},
					fontweight: function(feature)
					{
						feature_icon = feature.attributes.icon;
						if (feature_icon!=="")
						{
							return "normal";
						}
						else
						{
							return "bold";
						}
					},
					radius: function(feature)
					{
						feature_count = feature.attributes.count;
						if (feature_count > 1000) {
							return markerRadius * 7;
						}
						else if (feature_count > 900) {
							return markerRadius * 6.8;
						}
						else if (feature_count > 800) {
							return markerRadius * 6.6;
						}
						else if (feature_count > 700) {
							return markerRadius * 6.4;
						}
						else if (feature_count > 600) {
							return markerRadius * 6.2;
						}
						else if (feature_count > 500) {
							return markerRadius * 6;
						}
						else if (feature_count > 400) {
							return markerRadius * 5.7;
						}
						else if (feature_count > 300) {
							return markerRadius * 5.2;
						}
						else if (feature_count > 200) {
							return markerRadius * 4.7;
						}
						else if (feature_count > 100) {
							return markerRadius * 4.2;
						}
						else if (feature_count > 90) {
							return markerRadius * 4;
						}
						else if (feature_count > 80) {
							return markerRadius * 3.8;
						}
						else if (feature_count > 70) {
							return markerRadius * 3.6;
						}
						else if (feature_count > 60) {
							return markerRadius * 3.4;
						}
						else if (feature_count > 50) {
							return markerRadius * 3.2;
						}
						else if (feature_count > 40) {
							return markerRadius * 3;
						}
						else if (feature_count > 30) {
							return markerRadius * 2.8;
						}
						else if (feature_count > 20) {
							return markerRadius * 2.6;
						}
						else if (feature_count > 10) {
							return markerRadius * 2.4;
						}
						else {
							return markerRadius * 2;
						}
					},
					strokeWidth: function(feature)
					{
						if ( typeof(feature.attributes.strokewidth) != 'undefined' && 
							feature.attributes.strokewidth != '')
						{
							return feature.attributes.strokewidth;
						}
						else
						{
							feature_count = feature.attributes.count;
							if (feature_count > 10000)
							{
								return 18;
							}
							else if (feature_count > 5000)
							{
								return 16;
							}
							else if (feature_count > 1000)
							{
								return 14;
							}
							else if (feature_count > 100)
							{
								return 12;
							}
							else if (feature_count > 10)
							{
								return 10;
							}
							else if (feature_count >= 2)
							{
								return 5;
							}
							else
							{
								return 1;
							}
						}
					},
					color: function(feature)
					{
						return "#" + feature.attributes.color;
					},
					strokeColor: function(feature)
					{
						if ( typeof(feature.attributes.strokecolor) != 'undefined' && 
							feature.attributes.strokecolor != '')
						{
							return "#"+feature.attributes.strokecolor;
						}
						else
						{
							return "#"+feature.attributes.color;
						}
					},
					clusterCount: function(feature)
					{
						if (feature.attributes.count > 1)
						{
							if($.browser.msie && $.browser.version=="6.0")
							{ // IE6 Bug with Labels
								return "";
							}
							
							return feature.attributes.count;
						}
						else
						{
							return "";
						}
					},
					opacity: function(feature)
					{
						feature_icon = feature.attributes.icon;
						if (feature_icon!=="")
						{
							return "1";
						}
						else
						{
							return markerOpacity;
						}
					},
					labelalign: function(feature)
					{
						feature_icon = feature.attributes.icon;
						if (feature_icon!=="")
						{
							return "c";
						}
						else
						{
							return "c";
						}
					}
				}
			}
    );

    Styles = new OpenLayers.StyleMap({
        "default": style,
           "select":{
               fillColor: "#8aeeef",
           strokeColor: "#32a8a9"
           } 
    });

    
}



function onFeatureUnselect(event) {
    // Safety check
    if (event.feature.popup != null)
    {
      map.removePopup(event.feature.popup);
      event.feature.popup.destroy();
      event.feature.popup = null;
    }
}
/**
 * Close Popup
 */
function onPopupClose(event)
{
    selectCtrl.unselect(selectedFeature);
    selectedFeature = null;
};
