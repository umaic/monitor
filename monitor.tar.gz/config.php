<?php 

$config['base'] = 'monitor';
$config['base_path'] = $_SERVER['DOCUMENT_ROOT'].'/'.$config['base'];
$config['libraries'] = $config['base_path'].'/libraries';

?>
