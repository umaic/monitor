<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="favicon.ico" />
<title>OCHA Colombia :: Monitor</title>
<link type="text/css" rel="stylesheet" href="media/css/fe.min.css">
<link type="text/css" rel="stylesheet" href="media/css/slider_classic.min.css" />
<link type="text/css"rel="stylesheet" href="media/css/jquery-ui-1.8.22.custom.min.css" />
<script type="text/javascript" src="media/js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="media/js/jquery-ui-1.8.21.custom.min.js"></script>
<script type="text/javascript" src="media/js/openlayers/OpenLayers.min.js"></script>
<script type="text/javascript" src="media/js/openlayers/LoadingPanel.min.js"></script>
<script type="text/javascript" src="media/js/fe.min.js"></script>
<script type="text/javascript" src="media/js/map.min.js"></script>
<script type="text/javascript" src="media/js/url_tools.min.js"></script>
<script type="text/javascript" src="media/js/jQAllRangeSliders.min.js"></script>
</head>
<body>
    <div id="brand">
    </div>
    <div id="header">
        <div id="logo"></div>
        <div id="b">
            Monitor es una herramienta puesta a disposici&oacute;n de la comunidad 
            humanitaria en Colombia para poder visualizar la situaci&oacute;n 
            humanitaria en el pa&iacute;s de manera georeferenciada. <a href="#" id="lmh">Leer m&aacute;s</a>
            <div id="qlmh" class="hide">
                <div id="lmm">
                    <img src="media/img/logo.png" />
                </div>
                <div id="qmm">
                    Monitor es una herramienta puesta a disposici&oacute;n de la comunidad 
                    humanitaria en Colombia para poder visualizar la situaci&oacute;n 
                    humanitaria en el pa&iacute;s de manera georeferenciada. <br /><br />
                    Permite la visualizaci&oacute;n de multiples fuentes de informaci&oacute;n 
                    tanto de desastres naturales como de emergencia compleja.  
                    OCHA Colombia provee esta plataforma como un servicio com&uacute;n humanitario 
                    para el Equipo Humanitario del Pa&iacute;s (EHP) y los miembros de los respetivos Clusters
                </div>
            </div>
        </div>
    </div>
    <div id="menu">
        <div id="aaaa">
            <input type="hidden" id="currentCat" value="0">
            <input type="hidden" id="startDate" value="<?php echo strtotime('2012-1-1') ?>">
            <input type="hidden" id="endDate" value="<?php echo strtotime('2012-12-31') ?>">
            <?php 
            foreach($totalxy as $_a => $_t) { ?>
                <div class="v">
                    <div class="a">
                        <?php echo $_a ?>
                    </div>
                    <div>
                        <div class="circle ec"></div><div class="n"><?php echo $_t['ec'] ?></div>
                        <div class="circle dn clear"></div><div class="n"><?php echo $_t['dn'] ?></div>
                    </div>
                </div>
            <?php
            } 
            ?>
        </div>
    </div>
    <a href="http://colombiassh.org/emergenciacompleja/" target="_blank">
        <div id="tec" class="tecdn">
            <div>Total Eventos: <?php echo number_format($tec) ?></div>
        </div>
    </a>
    <a href="http://inundaciones.colombiassh.org/" target="_blank">
        <div id="tdn" class="tecdn">
            <div>Total Eventos: <?php echo number_format($tdn) ?></div>
        </div>
    </a>
        <div id="loading" class="alpha60">
            <img src="media/img/ajax-loader.png" />
        </div>
    <div id="content">
        <div id="ys"></div>
        <div id="map"></div>
        <div id="totalxd" class="shadow">
            <h1>Eventos por Departamento</h1>
            <h2 id="totalxd_y">2012</h2>
            <div id="dslider"></div>
            <table>
            <?php
            foreach($totalxd as $_t) {
                echo '<tr>
                        <td class="left">'.$_t['d'].'</td>
                        <td class="ec">'.$_t['ec'].'</td>
                        <td class="dn">'.$_t['dn'].'</td>
                        <td class="hide centroid">'.$_t['c'].'</td>
                      </tr>
                '; 
            }
            ?>
        </div>
    </div>
    <div id="footer">
    </div>
</body>
</html>

