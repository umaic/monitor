<?php 
/** 
 * Monitor(tm) : Rapid Development Framework (http://monitor.colombiassh.org)
 * Copyright 2012, OCHA Colombia (http://colombiassh.org)
 *
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * PHP version 5
 *
 * @category  Script
 * @package   Monitor
 * @author    Ruben Rojas <rojasr@un.org>
 * @copyright 2012 OCHA Colombia (http://colombiassh.org)
 * @license   MIT License (http://www.opensource.org/licenses/mit-license.php)
 * @link      http://monitor.colombiassh.org Monitor
*/

session_start();

// PHP >= 5.3
//date_default_timezone_set('America/Bogota');

require 'controllers/monitor.php';
$mc = new MonitorController;

$totalxy = $mc->total();
$totalxd = $mc->totalxd();
$_t = $mc->totalecdn();
$tec = $_t['ec'];
$tdn = $_t['dn'];

require 'views/layout.php';

?>
